/* Sieve starter code and activity herein a derivative work of --
 * Parallelization:  Sieve of Eratosthenes
 * By Aaron Weeden, Shodor Education Foundation, Inc.
 * January 2012
 *
 * Starter code
 *  -- to run, use ./sieve.starter -n N, where N is the value under which to find
 *     primes.
 *  -- see attached module document for discussion of the code and its algorithm
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <omp.h>

#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

int main(int argc, char **argv) {
    /* Declare variables */
    long N = 16; /* The positive integer under which we are finding primes */
    long sqrtN = 4; /* The square root of N, which is stored in a variable to 
                      avoid making excessive calls to sqrt(N) */
    long c = 2; /* Used to check the next number to be circled */
    long m = 3; /* Used to check the next number to be marked */
    long *list; /* The list of numbers -- if list[x] equals 1, then x is marked. 
                  If list[x] equals 0, then x is unmarked. */
    char next_option = ' '; /* Used for parsing command line arguments */
    double start, end;
    long counter;
   
    /* Parse command line arguments -- enter 'man 3 getopt' on a shell to see
       how this works */
    while((next_option = getopt(argc, argv, "n:")) != -1) {
        switch(next_option) {
            case 'n':
                N = atoi(optarg);
                break;
            case '?':
            default:
                fprintf(stderr, "Usage: %s [-n N]\n", argv[0]);
                exit(-1);
        }
    }

    printf("Solving for n = %ld\n",N);


    /* Calculate sqrtN */
    sqrtN = (long)sqrt(N);

    /* Allocate memory for list */
    list = (long*)malloc(N * sizeof(long));

    /* Exit if malloc failed */
    if(list == NULL) {
        fprintf(stderr, "Error: Failed to allocate memory for list.\n");
        exit(-1);
    }

    start = omp_get_wtime();
    /* Run through each number in the list */
    for(c = 2; c <= N-1; c++) {

        /* Set each number as unmarked */
        list[c] = 0;
    }

    /* Run through each number in the list up through sqrtN */
    for(c = 2; c <= sqrtN; c++) {

        /* If the number is unmarked */
        if(list[c] == 0) {

            /* Run through each number bigger than c */
            for(m = c*c; m <= N-1; m+=c) {
                list[m] = 1;
            }
        }
    }
    end = omp_get_wtime();


    /* Run through each number in the list */
    counter=0;
    for(c = 2; c <= (N-1)/2 && counter < 10; c++) {

        /* If the number is unmarked */
        if(list[c] == 0) {

            /* The number is prime, print it */
            printf("%ld ", c);
            counter++;
        }
    }
    printf("\n");
        /* Run through each number in the list */
    counter=0;
    for(c = N-1; c > (N-1)/2 && counter<10; c--) {

        /* If the number is unmarked */
        if(list[c] == 0) {

            /* The number is prime, print it */
            printf("%ld ", c);
            counter++;
        }
    }
    printf("\n");
    printf("Elapsed time in calculation: %lf (s)\n",(end-start));

    /* Deallocate memory for list */
    free(list);

    return 0;
}