#include <set>
#include <iostream>
#include <assert.h>
#include <vector>

using namespace std ;

void vec_mult (int N, const int n_print =10){
	double p[N] , v1[N] , v2[N] ;
	for(int ii =0; ii <N; ++ ii ) {
		p [ ii ] = ii %5;
		v1 [ ii ] = ii %6;
		v2 [ ii ] = ii %7;
	}

	int i ;
	#pragma omp target map( to : v1[0:N] , v2[0:N] , p[0:N] )
	#pragma omp parallel for private(i)
	for ( i =0; i <N; i ++ ) {
		p [i] = v1 [i] * v2 [i] ;
	}

	int num_print = 0;
	if( n_print > N) num_print = N;
	else num_print = n_print ;
	for(int ii =0; ii <num_print ; ++ ii ) 
		cout << p [ ii ] << "  " ;
	cout << endl ;
}

int main (int argc , char * * argv )
{
	cout << "#########################################" << endl ;
	cout << "#######      Test Start         #########" << endl ;
	cout << "#########################################" << endl << endl ;
	vec_mult (100000 );
	cout << "Test complete!\n" ;
	return 0;
}
