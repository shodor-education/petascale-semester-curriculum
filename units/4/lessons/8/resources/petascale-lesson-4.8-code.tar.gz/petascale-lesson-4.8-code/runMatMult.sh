#!/bin/bash


# BASH shell script to automate timing results for
# various size matrices and various number of threads
make matMult

# Output file variable, in case I want to run the
# script again with a different name.  Change once
# use often!
OUTFILE=Output.txt

# Remove the output file if it exists because the
#loop below appends to the file.
if [ -f $OUTFILE ]; then
   rm -f $OUTFILE
fi

# Run the program for matrices for size 100, 200, ... 1400
# and variuos number of threads.  Go have a cup a coffee
# and let the machine do the work!!
COUNTER=100
while [ $COUNTER -le 1400 ]; do
    echo $COUNTER		#Progress Visualization
    echo "matMult" $COUNTER 2 >> $OUTFILE
    ./matMult $COUNTER 2 >> $OUTFILE
    echo "matMult" $COUNTER 4 >> $OUTFILE
    ./matMult $COUNTER 4 >> $OUTFILE
    echo "matMult" $COUNTER 8 >> $OUTFILE
    ./matMult $COUNTER 8 >> $OUTFILE
    echo "matMult" $COUNTER 16 >> $OUTFILE
    ./matMult $COUNTER 16 >> $OUTFILE
    echo >> $OUTFILE
    let COUNTER=COUNTER+100
done
