########
#
# Written by Michael N Groves
# California State University Fullerton
# July 17, 2020
#
#######

import numpy as np      # Importing NumPy
import matplotlib.pyplot as plt     # Importing MatPlotLib

# Setting up x and y data
x=[1,1.5,2,2.5,3,3.5]
y=[1.0,3.0,3.9,5.05,5.8,7.9]

# Fitting the x and y data to a line
fit=np.polyfit(x,y,1)  #np.polyfit is a NumPy fitting function 
fitfunction=np.poly1d(fit)   #Take the output of polyfit and makes a function

# Plotting data
plt.plot(x,y,'bo')   # Plot the original x,y data
plt.plot(x,fitfunction(x),'r-')     # Plot the fitted data

# Axis labeling.  Argument is a string
plt.xlabel('Concentration (M)')
plt.ylabel('Amplitude (arb.)')

####### Only uncomment one at a time
### Show the plot
# plt.show()

### Save the plot
# plt.savefig('My_Figure.pdf')
