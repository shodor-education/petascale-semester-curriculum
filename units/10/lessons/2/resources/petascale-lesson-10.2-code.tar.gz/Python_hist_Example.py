########
#
# Written by Michael N Groves
# California State University Fullerton
# July 17, 2020
#
#######

import numpy as np      # Importing NumPy
import matplotlib.pyplot as plt     # Importing MatPlotLib

# Setting up the data and the bins
### np.random.random_sample generates n random numbers in [0,1)
### This is multiplied by 10 to get [0,10)
data=np.random.random_sample(1000)*10
### Setting up the bins so that the data is grouped into integers
### Must include the minimum limit on the bottom bin
### and the maximum limit on the top bin
mybins = [0,1,2,3,4,5,6,7,8,9,10]

# Plotting data
plt.hist(x=data,bins=mybins)

# Axis labeling.  Argument is a string
plt.xlabel('Data')
plt.ylabel('Frequency')

####### Only uncomment one at a time
### Show the plot
# plt.show()

### Save the plot
# plt.savefig('My_Figure.pdf')
