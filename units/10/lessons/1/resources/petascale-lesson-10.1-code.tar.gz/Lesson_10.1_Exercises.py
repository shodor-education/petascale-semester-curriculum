### Question 1

a=8
b=4
print(a+b)

### Question 2

c='My Word'
for letter in c:
    print(letter)

### Question 3

my_number = 4

if my_number > 5:
    print('Your number is greater than 5')
elif my_number < 5:
    print('Your number is less than 5')
else:
    print('Your number is equal to 5')
