%A=importdata('out3.txt');
Npart=10000;
Ntime=100;
fx=fopen('xout.bin','r');
fy=fopen('yout.bin','r');
fz=fopen('zout.bin','r');
x=fread(fx,[Npart,Ntime],'double');
y=fread(fy,[Npart,Ntime],'double');
z=fread(fz,[Npart,Ntime],'double');
%x=reshape(A(:,1),[Npart,Ntime]);
%y=reshape(A(:,2),[Npart,Ntime]);
%z=reshape(A(:,3),[Npart,Ntime]);
%clear A

maxx=2*max(abs(x(:,1)));
maxy=2*max(abs(y(:,1)));
maxz=2*max(abs(z(:,1)));
clear F;
F(Ntime) = struct('cdata',[],'colormap',[]);

%now we plot the frames
for j = 1:Ntime
    hold off
    plot3(x(:,j),y(:,j),z(:,j),'o')
    axis([-maxx maxx -maxy maxy -maxz maxz])
    drawnow
    F(j) = getframe;
end
% Once this script is run, you can replay the
% movie interactively with the command
% movie(F)