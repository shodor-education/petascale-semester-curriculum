from mpi4py import MPI                 # Imports the MPI Framework
comm = MPI.COMM_WORLD                  # Saves information about all processes
rank = comm.Get_rank()                 # Tells this process what rank it is
print(‘My rank is {}’.format(rank))    # Prints to the screen a process’ rank

####
#
# Uncomment when ready
#
####

#if rank == 0:
#    print(“Hello World from rank {}”.format(rank))
#else:
#    print(“I am rank {}”.format(rank))

####
#
# Try to write a conditional that will only print "Hello World" from even
# numbered processes that scales arbitarily
#
####
