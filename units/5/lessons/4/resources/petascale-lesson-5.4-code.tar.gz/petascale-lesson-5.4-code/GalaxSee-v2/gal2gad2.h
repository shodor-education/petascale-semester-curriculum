#ifndef GAL2GAD2
#define GAL2GAD2
#include "nbody.h"
int gal2gad2(NbodyModel *theModel,const char * prefix,const char * path,double length, double mass, double velocity);
#endif
