/*The Parallel Hello World Program*/
#include <stdio.h>
#include <mpi.h>

/* Simple MPI code:

Sample Use:
Compile: %mpicc -o hello_world hello_world.c
Run    : %mpiexec -n 8 ./hello_wolrd

Input: None
Description: Each node displays " a Hello World from it to all other through Message Passing Method  "

Output:  " Hello World from Node ID "

*/

main(int argc, char **argv)
{
   int node;
   
   MPI_Init(&argc,&argv);
   MPI_Comm_rank(MPI_COMM_WORLD, &node);
     
   printf("Hello World from  Me on Node %d\n",node);
            
   MPI_Finalize();
}
