#!/bin/bash

####################################################################################################################################
# This script will allocate a total of 64 cores, 16 MPI processes (2 node * 8 ntask-per-node = 16), If is parallelized with OpenMP #
# then each process will spawn 4 threads, one per core.                                                                            #
####################################################################################################################################



export mypath=`pwd`
sbatch --job-name=mpi_example --nodes=2	--ntasks=16 --ntasks-per-node=8 --cpus-per-task=4 --time=00:30:00 --partition=normal -o slurm%j.out -e slurm%j.err <<ENDINPUT
#!/bin/bash

module load impi/18.0.2
export OMP_NUM_THREADS=8

# Set executable fille
export myfile=$1
# Go to working directory (submission directory)
cd $mypath
echo "Current working directory is: " `pwd`
# Execute job
time ibrun \${myfile}
ENDINPUT
