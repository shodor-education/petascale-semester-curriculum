#!/bin/bash


# BASH shell script to automate timing results for
# various strides through a linear array

# make sure the program is made and ready to go
make memStrideT


# Output file variable, in case I want to run the
# script again with a different name.  Change once
# use often!
OUTFILE=memStrideUnsignedChar


# Remove the output file if it exists because the
# loop below appends to the file.
if [ -f $OUTFILE.csv ]; then
   rm -f $OUTFILE.csv
fi

#Run the program using stride of 1 to 132 with 100Mibe elements
COUNTER=1
while [ $COUNTER -le 133 ]; do
	echo $COUNTER		#Progress Visualization
	./memStrideT 100 $COUNTER >> $OUTFILE.csv
	let COUNTER=COUNTER+1
done


#Run the program using stride of 128,256,512,1024,248,4096 with 100Mib of memory
COUNTER=256
while [ $COUNTER -le 4096 ]; do
	echo $COUNTER
	./memStrideT 100 $COUNTER >> $OUTFILE.csv
	let COUNTER=COUNTER*2
done
