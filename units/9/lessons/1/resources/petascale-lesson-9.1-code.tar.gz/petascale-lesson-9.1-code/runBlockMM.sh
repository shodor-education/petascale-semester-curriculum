#!/bin/bash

# BASH shell script to automate timing results for
# various size matrices and various number of threads

# make sure the program is current
make blockMM

# Output file variable, in case I want to run the
# script again with a different name.  Change once
# use often!
OUTFILE=mmBlock.txt

# Remove the output file if it exists because the
# loop below appends to the file.
if [ -f $OUTFILE ]; then
   rm -f $OUTFILE
fi

# Run the program for matrices for size 100, 200, ... 1500
# and variuos number of threads.  Go have a cup a coffee
# and let the machine do the work!!
COUNTER=100
while [ $COUNTER -le 1500 ]; do
    echo $COUNTER		#Progress Visualization
    echo $COUNTER 2 >> $OUTFILE
    ./blockMM $COUNTER 2 >> $OUTFILE
    echo $COUNTER 4 >> $OUTFILE
    ./blockMM $COUNTER 4 >> $OUTFILE
    echo $COUNTER 8 >> $OUTFILE
    ./blockMM $COUNTER 8 >> $OUTFILE
    echo $COUNTER 16 >> $OUTFILE
    ./blockMM $COUNTER 16 >> $OUTFILE
    echo $COUNTER 32 >> $OUTFILE
    ./blockMM $COUNTER 32 >> $OUTFILE
    echo $COUNTER 64 >> $OUTFILE
    ./blockMM $COUNTER 64 >> $OUTFILE
    echo $COUNTER 128 >> $OUTFILE
    ./blockMM $COUNTER 128 >> $OUTFILE
    let COUNTER=COUNTER+100
    echo >> $OUTFILE
done
