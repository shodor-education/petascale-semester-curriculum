#!/bin/bash

# BASH shell script to automate timing results for
# various size matrices and various number of threads

# make sure the program is current
make matMult

# Output file variable, in case I want to run the
# script again with a different name.  Change once
# use often!
OUTFILE=mmTranspose.txt

# Remove the output file if it exists because the
# loop below appends to the file.
if [ -f $OUTFILE ]; then
   rm -f $OUTFILE
fi

# Run the program for matrices for size 100, 200, ... 1500
# and variuos number of threads.  Go have a cup a coffee
# and let the machine do the work!!
COUNTER=100
while [ $COUNTER -le 1500 ]; do
    echo $COUNTER		#Progress Visualization
    echo $COUNTER >> $OUTFILE
    ./matMult $COUNTER >> $OUTFILE
    let COUNTER=COUNTER+100
    echo >> $OUTFILE
done
