# CUDA OpenGL

Run `python3 build.py` in order to build the project
