#include "mimage.h"

// See https://en.wikipedia.org/wiki/Mandelbrot_set
// This uses a naive algorithm. For better algorithms, see also
// https://en.wikipedia.org/wiki/Plotting_algorithms_for_the_Mandelbrot_set

#define INT(x) ((int)(x))
#define IMAGE_NX 1024
#define IMAGE_NY 1024

// xorig,yorig -- center of image
// scale -- scale factor from x,y to pixels
static double xorig,yorig,scale;

static mcolor mandelbrot_color(double x, double y);
static double mapx(int ix);
static double mapy(int iy);
static void mandelbrot_init_color_map();

int main(int argc, char **argv)
{
 xorig = 0.;
 yorig = 0.;
 scale = 3./IMAGE_NX;

 if(argc >= 3)
   {xorig = atof(argv[1]);
    yorig = atof(argv[2]);
   }
 if(argc == 4)
   {
    scale = scale/atof(argv[3]);
   }

 mandelbrot_init_color_map();
 mimage *image = mimage_new(IMAGE_NX,IMAGE_NY);
 for(int iy=0;iy<image->ny;iy++)
   for(int ix=0;ix<image->nx;ix++)
     {
      mimage_set_pixel(image, ix, iy, mandelbrot_color(mapx(ix),mapy(iy)));
     }
   for(int ix=0;ix<image->nx;ix++)
     {
      mimage_set_pixel(image, ix, 500, mandelbrot_color(mapx(ix),mapx(ix)));
      mimage_set_pixel(image, ix, 501, mandelbrot_color(mapx(ix),mapx(ix)));
      mimage_set_pixel(image, ix, 502, mandelbrot_color(mapx(ix),mapx(ix)));
      mimage_set_pixel(image, ix, 503, mandelbrot_color(mapx(ix),mapx(ix)));
      mimage_set_pixel(image, ix, 504, mandelbrot_color(mapx(ix),mapx(ix)));
      mimage_set_pixel(image, ix, 505, mandelbrot_color(mapx(ix),mapx(ix)));
     }
 mimage_write_png(image,"ttest.png");
 mimage_free(image);
}

static double mapx(int ix)
{
 return xorig + scale*(ix-IMAGE_NX/2);
}

static double mapy(int iy)
{
 return yorig + scale*(iy-IMAGE_NY/2);
}

#define KMAX 6
static int mandelbrot(double x0, double y0)
{
 double x,y;
 x = 0.;
 y = 0.;

 int k = 0;
 while( ((x*x+y*y) < 4.) && (k < KMAX*5) )
   {
    double x1 = x*x-y*y + x0;
    double y1 = 2.*x*y + y0;
    x = x1;
    y = y1;
    k = k + 1;
   }
 if(k >= KMAX*5) return KMAX;

 return k % KMAX;
}

static mcolor mandelbrot_color_map[KMAX+1];

static mcolor mandelbrot_color(double x, double y)
{
 int mandelbrot_count = mandelbrot(x, y);
// printf("x %lf y %lf count %d\n",x,y,mandelbrot_count);
 return mandelbrot_color_map[mandelbrot_count];
}

static void mandelbrot_init_color_map()
{
 mandelbrot_color_map[5] = MCOLOR_RED;
 mandelbrot_color_map[4] = MCOLOR_YELLOW;
 mandelbrot_color_map[3] = MCOLOR_GREEN;
 mandelbrot_color_map[2] = MCOLOR_CYAN;
 mandelbrot_color_map[1] = MCOLOR_MAGENTA;
 mandelbrot_color_map[0] = MCOLOR_BLUE;
 mandelbrot_color_map[6] = MCOLOR_BLACK;

}

