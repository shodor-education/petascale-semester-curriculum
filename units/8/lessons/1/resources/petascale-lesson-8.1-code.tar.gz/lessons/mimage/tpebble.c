#include "mimage.h"

//
//   tpebble makes the pebble images from the pebble module....
//

// See https://en.wikipedia.org/wiki/Mandelbrot_set
// This uses a naive algorithm. For better algorithms, see also
// https://en.wikipedia.org/wiki/Plotting_algorithms_for_the_Mandelbrot_set

#define INT(x) ((int)(x))
#define IMAGE_NX 512
#define IMAGE_NY 512
#define GMAX 512
/*
#define nx 512
#define ny 512
*/

// xorig,yorig -- center of image
// scale -- scale factor from x,y to pixels
static double xorig,yorig,scale;

static mcolor mandelbrot_color(double x, double y);
static double mapx(int ix);
static double mapy(int iy);
static void mandelbrot_init_color_map();

//
//   main program for image making 
//
int main(int argc, char **argv)
{

FILE  *frgbptr;
FILE  *fnameptr;
FILE  *fhdrptr;

// int   image[512][512];
//
//   function defined in the mimage.h file
//

//! \brief mimage_set_pixel -- set a pixel in an image.
//!
//! Note that this is inlined, so it will compile to direct code.
//static inline void mimage_set_pixel(mimage *image, int ix, int iy, mcolor pixel)
//{
//  image->data[ix + image->stride * iy] = pixel;
//}

// build a white screen background
//
//    open a file with an image
//
//         file name of image
//         hdr file for image
//         data file with image
// mimage_write_png(image,"data/gray_frame00001.png");
// fnameptr  =   fopen ("data/gray_frame.filenames","r");
// fhdrptr   =   fopen ("data/gray_frame.hdr","r");
// fnameptr  =   fopen ("../testImageMagik/data/gray_frame.filenames","r");
// fhdrptr  =   fopen ("../testImageMagik/data/gray_frame.hdr","r");
// sprintf(dirfilename,"../testImageMagik/data/gray_frame00000.dat");
//sprintf(dirfilename, "../MPI-5.1-Waves/data/pebble_frame00000.dat");
//    
//                      ../MPI-5.1-Waves/data/pebble.filenames
//                      ../MPI-5.1-Waves/data/pebble.hdr
//                      ../MPI-5.1-Waves/data/pebble.mvlp

//                      ../Vis-10.7-Movie/data/pebble.filenames
//                      ../Vis-10.7-Movie/data/pebble.hdr
//                      ../Vis-10.7-Movie/data/pebble.mvlp

  fnameptr  =   fopen ("../Vis-10.7-Movie/data/pebble.filenames","r");

  fhdrptr  =   fopen ("../Vis-10.7-Movie/data/pebble.hdr","r");

int  nxf;
int  nzf;
int  nframef;
int  nfcharf;
  fread(&nframef,sizeof(int),1,fhdrptr);
  fread(&nxf,sizeof(int),1,fhdrptr);
  fread(&nzf,sizeof(int),1,fhdrptr);
  fread(&nfcharf,sizeof(int),1,fhdrptr);
  fclose(fhdrptr);

  printf("\n    ");
  printf("\n   Making an GraphicsMagick movie loop   ");
  printf("\n    ");
  printf("\n    number of frames is %d",nframef);
  printf("\n    ndx dimension is %d",nxf);
  printf("\n    ndz dimension is %d",nzf);
  printf("\n    number of char is %d",nfcharf);
  printf("\n    ");

  char filename[27];
  char dirfilename[45];

//  fhdrptr  =   fopen ("../testImageMagik/data/gray_frame.hdr","r");
//  mimage_write_png(image,"../testImageMagik/data/gray_frame00001.png");
//                          123456789012345678901234567890123456789012      
//                                   0     6   0         0      7890123
//                                   1     1   2         3      3334444
//   dirfilename[0] =  "../testImageMagik/                          "
//                      123456789012345678
//   dirfilename[0] =  "../testImageMagik/                    .png"
//                                        123456789012345678901234           
//                                                 1         2
// sprintf(dirfilename,"../testImageMagik/data/gray_frame00000.dat");
//char filename[25];
// char dirfilename[43];
//     dirfilename is one character longer.....
   sprintf(dirfilename,"../Vis-10.7-Movie/data/pebble_mvlp00000.dat");
//char filename[26];
// char dirfilename[44];

    printf("%s",dirfilename);
    printf("test");
    printf("\n movie frame loop   ");

  int wave_pixel;

// loop over movie frames

  for(int iframe=0;iframe<nframef;iframe++)
{
//  open frame file

  fgets(filename,26,fnameptr);
// add the directory to head of data file name
  for (int icm=0;icm<26;icm++)
    {
       dirfilename[icm+18] = filename[icm];
    }

  frgbptr      =   fopen (dirfilename,"rb");
 mimage *image = mimage_new(IMAGE_NX,IMAGE_NY);
 for(int iy=0;iy<image->ny;iy++)
   for(int ix=0;ix<image->nx;ix++)
     {
//      read the pixel value for this i,j image location

        fread(&wave_pixel,sizeof(int),1 ,frgbptr);

//      set the pixel value in the png image

        mimage_set_pixel(image, ix, iy, wave_pixel );
     }
//      set the file name
// mimage_write_png(image,"../testImageMagik/data/gray_frame00001.png");
 dirfilename[40] = 'p';
 dirfilename[41] = 'n';
 dirfilename[42] = 'g';
 mimage_write_png(image,dirfilename);
 mimage_free(image);
 fclose(frgbptr);

} // end of movie loop conversion to png files

 fclose(fnameptr);

//
//   End of Main Program for Image Making.....
//
}




