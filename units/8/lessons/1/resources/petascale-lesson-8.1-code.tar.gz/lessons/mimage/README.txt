This project contains a small image library. See mimage.h for the
image structure definition, but to summarize an image is an array
of pixels in memory, where a pixel is ARGB stored in an unsigned int.

The library supports reading and writing to PNG and JPEG file formats.
There is no guarantee that all PNG and all JPEG files are supported,
only the ones that have been tested. See examples subdirectory for
test images.

The library depends on libpng and jpeg, see INSTALL.txt for instructions.

Several test programs are provided, including a mandelbrot example and
programs to read and write PNG and JPEG images.



