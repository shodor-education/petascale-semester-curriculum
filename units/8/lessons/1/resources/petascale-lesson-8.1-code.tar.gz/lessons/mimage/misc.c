#include "misc.h"

void misc_info(const char *fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);
  vfprintf(stdout, fmt, ap);
  va_end(ap);
}

void misc_warn(const char *fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);
  vfprintf(stderr, fmt, ap);
  va_end(ap);
}

void misc_fatal(const char *fmt, ...)
{
  char line[1024];

  va_list ap;

  va_start(ap, fmt);
  vsprintf(line, fmt, ap);
  va_end(ap);

  fprintf(stderr, "FATAL ERROR: %s\nending program.\n\n",line);
  misc_abort(); // wont return
}


void misc_exit(int status)
{
  exit(status);
}

void misc_abort()
{
  int *p = NULL;

  p[0] = 1; // that should do it!
}



void *misc_alloc(long l)
{
  if(l == 0) return NULL;
  return malloc(l);
}

void misc_free(void *ptr)
{
  if(ptr == NULL) return;
  free(ptr);
}

