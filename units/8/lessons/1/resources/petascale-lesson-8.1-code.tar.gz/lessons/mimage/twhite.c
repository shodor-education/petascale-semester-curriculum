#include "mimage.h"

// See https://en.wikipedia.org/wiki/Mandelbrot_set
// This uses a naive algorithm. For better algorithms, see also
// https://en.wikipedia.org/wiki/Plotting_algorithms_for_the_Mandelbrot_set

#define INT(x) ((int)(x))
#define IMAGE_NX 256
#define IMAGE_NY 256
#define GMAX 256
/*
#define nx 256
#define ny 256
*/

// xorig,yorig -- center of image
// scale -- scale factor from x,y to pixels
static double xorig,yorig,scale;

static mcolor mandelbrot_color(double x, double y);
static double mapx(int ix);
static double mapy(int iy);
static void mandelbrot_init_color_map();

//
//   main program for image making 
//
int main(int argc, char **argv)
{

// int   image[256][256];
//
//   function defined in the mimage.h file
//

//! \brief mimage_set_pixel -- set a pixel in an image.
//!
//! Note that this is inlined, so it will compile to direct code.
//static inline void mimage_set_pixel(mimage *image, int ix, int iy, mcolor pixel)
//{
//  image->data[ix + image->stride * iy] = pixel;
//}

// build a white screen background
//
//    open a file with an image
//

mimage *image = mimage_new(IMAGE_NX,IMAGE_NY);
 for(int iy=0;iy<image->ny;iy++)
   for(int ix=0;ix<image->nx;ix++)
     {
//      read the pixel value for this i,j image location

//      set the pixel value in the png image

        mimage_set_pixel(image, ix, iy, -1  );
     }
//      set the file name
//
 mimage_write_png(image,"tgrey00001.png");
 mimage_free(image);
//
//   End of Main Program for Image Making.....
//
}




