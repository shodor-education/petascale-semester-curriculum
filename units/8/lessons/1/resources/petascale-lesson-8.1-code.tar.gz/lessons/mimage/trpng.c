#include "mimage.h"

int main(int argc, char **argv)
{
  mimage *image = mimage_read_png(argv[1]);
  mimage_write_png(image, "/tmp/trpng.png");
  system("display /tmp/trpng.png ; rm -f /tmp/trpng.png;");
  mimage_free(image);
}
