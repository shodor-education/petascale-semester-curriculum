#include <stdio.h>
#include <string.h>
 
int main( ) 
{
   int value = 50 ; 
   float flt = 7.25 ; 
   char c = 'Z' ; 
   char cn[10] = {'\0'} ; 
   char string[40] = {'\0'} ; 
   char basefilename[50] = {'\0'} ; 
   char filename[25] = {'\0'} ; 
   

   printf ( "int value = %d \n char value = %c \n " \
            "float value = %f", value, c, flt ) ; 

/*   Now, all the above values are redirected to string 
     instead of stdout using sprint */
 
   printf("\n Before using sprint, data in string is %s", string);
   sprintf ( string, "%d %c %f", value, c, flt );
   printf("\n After using sprint, data in string is %s", string);
   printf("\n ");

   filename[0] = 'g';
   filename[1] = 'r';
   filename[2] = 'a';
   filename[3] = 'y';
   filename[4] = '_';

   basefilename[0] = 'd';
   basefilename[1] = 'a';
   basefilename[2] = 't';
   basefilename[3] = 'a';
   basefilename[4] = '/';

   for (int icm=0;icm<5;icm++ )
      {
        basefilename[icm+5] = filename[icm];
      }

   printf("\n Before using sprint, data in basefilename string is %s x", basefilename);
   sprintf ( basefilename, "%10c", 'zzzzz10005' );
   printf("\n After using sprint, data in basefilename string is %s x", basefilename);
   printf("\n Before using sprint, data in filename string is %s x", filename);

   printf("\n ");
   return 0;
}
