#ifndef MISC_H
#define MISC_H 1

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

void    misc_info(const char *fmt, ...);
void    misc_warn(const char *fmt, ...);
void    misc_fatal(const char *fmt, ...);
void    misc_abort(void);
void    misc_exit(int status);

void *misc_alloc(long l);
void misc_free(void *ptr);

#define misc_alloc_type(type) (type *) misc_alloc(sizeof(type))
#define misc_alloc_array(type, n) (type *) misc_alloc(sizeof(type) * n)
#define misc_realloc_array(type,  p, n) (type *) misc_realloc(p, sizeof(type) * n)

#endif
