#include "mimage.h"

int main(int argc, char **argv)
{
  printf("Hello, world\n");
  mimage *image = mimage_new(512, 512);
  mimage_free(image);
}
