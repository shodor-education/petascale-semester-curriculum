#include "stdio.h"
#include "stdlib.h"
#include "math.h"
/*
        program chartest.c
        Phil Bording

        July 25, 2020

        test of making a list of numbers into characters 

*/

int main(  )
{

int count;

    for(count =0;count<11;count++)
    {
       printf("  %6d   ",count);
       printf("  %6.6d   ",count);
       printf(" data/name%6.6d.dat  ",count);
       printf(" \n");

    }

char   filename[20];
char   dirname[5];
char   dirfilenamex[25];
char   dirfilename[25];

       sprintf(dirname,"data/");

       sprintf(filename,"gray_names00000.dat");

       sprintf(dirfilenamex,"data/gray_names00000.dat");
       sprintf(dirfilenamex,"junk/gray_names00000.dat");

       for (int icm=0;icm<5;icm++) 
          {
            dirfilename[icm] = dirname[icm];
          }
       for (int icm=0;icm<20;icm++) 
          {
            dirfilename[icm+5] = filename[icm];
          }

        printf("%s",dirname);
        printf(" \n");
        printf("%s",filename);
        printf(" \n");
        printf("%s",dirfilenamex);
        printf(" \n");
        printf("%s",dirfilename);
        printf(" \n");

//       sprintf("gray_names00000.dat",filename);


}  /*  end of main  */

