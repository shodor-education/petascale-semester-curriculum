#include "mimage.h"

int main(int argc, char **argv)
{
  mimage *image = mimage_read_jpeg(argv[1]);
  int status = mimage_write_png(image, "/tmp/trjpeg.png");
  system("display /tmp/trjpeg.png ; rm -f /tmp/trjpeg.png;");
  mimage_free(image);
}
