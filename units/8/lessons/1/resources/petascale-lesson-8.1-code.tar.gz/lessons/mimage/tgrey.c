#include "mimage.h"

// See https://en.wikipedia.org/wiki/Mandelbrot_set
// This uses a naive algorithm. For better algorithms, see also
// https://en.wikipedia.org/wiki/Plotting_algorithms_for_the_Mandelbrot_set

#define INT(x) ((int)(x))
#define IMAGE_NX 512
#define IMAGE_NY 512
#define GMAX 512
/*
#define nx 512
#define ny 512
*/

// xorig,yorig -- center of image
// scale -- scale factor from x,y to pixels
static double xorig,yorig,scale;

static mcolor mandelbrot_color(double x, double y);
static double mapx(int ix);
static double mapy(int iy);
static void mandelbrot_init_color_map();

//
//   main program for image making 
//
int main(int argc, char **argv)
{

FILE  *frgbptr;
FILE  *fnameptr;
FILE  *fhdrptr;

// int   image[512][512];
//
//   function defined in the mimage.h file
//

//! \brief mimage_set_pixel -- set a pixel in an image.
//!
//! Note that this is inlined, so it will compile to direct code.
//static inline void mimage_set_pixel(mimage *image, int ix, int iy, mcolor pixel)
//{
//  image->data[ix + image->stride * iy] = pixel;
//}

// build a white screen background
//
//    open a file with an image
//
      

  fnameptr  =   fopen ("data/pebble.filenames","r");

  fhdrptr  =   fopen ("data/pebble.hdr","r");
int  nxf;
int  nzf;
int  nframef;
  fread(&nframef,sizeof(int),1,fhdrptr);
  fread(&nxf,sizeof(int),1,fhdrptr);
  fread(&nzf,sizeof(int),1,fhdrptr);
  fclose(fhdrptr);

  char filename[26];


  int wave_pixel;

// loop over movie frames

  for(int iframe=0;iframe<nframef;iframe++)
{
//  open frame file
  fgets(filename,26,fnameptr);
  frgbptr      =   fopen (filename,"rb");
 mimage *image = mimage_new(IMAGE_NX,IMAGE_NY);
 for(int iy=0;iy<image->ny;iy++)
   for(int ix=0;ix<image->nx;ix++)
     {
//      read the pixel value for this i,j image location

        fread(&wave_pixel,sizeof(int),1 ,frgbptr);

//      set the pixel value in the png image

        mimage_set_pixel(image, ix, iy, wave_pixel );
     }
//      set the file name
// mimage_write_png(image,"data/tgrey00001.png");
 filename[22] = 'p';
 filename[23] = 'n';
 filename[24] = 'g';
 mimage_write_png(image,filename);
 mimage_free(image);
 fclose(frgbptr);

} // end of movie loop conversion to png files

 fclose(fnameptr);

//
//   End of Main Program for Image Making.....
//
}




