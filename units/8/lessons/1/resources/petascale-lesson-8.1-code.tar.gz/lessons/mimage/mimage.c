#include "mimage.h"

mimage *mimage_new(int nx, int ny)
{
  mimage *image = misc_alloc_type(mimage);
  image->nx = nx;
  image->ny = ny;
  image->stride = nx;
  image->data = misc_alloc_array(mcolor, nx*ny);
  return image;
}

void mimage_free(mimage *image)
{
  misc_free(image->data);
  misc_free(image);
}
