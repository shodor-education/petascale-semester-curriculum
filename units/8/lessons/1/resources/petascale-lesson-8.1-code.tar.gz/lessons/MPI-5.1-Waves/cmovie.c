/*    c program to read the pebble movie loop 
      floating point file

      test code to prepare for doing tpebble.c

      Phil Bording
      July 15, 2020
      Blue Waters Project

*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>


int main()
{

    int nx;
    int nz;
    int frame_length;
    int nfchar;

    int nframe;

    character filename[26];

    frame_length = 256*256;

    float wave[256*256];

    FILE  *fmovie_ptr;
    FILE  *fheader_ptr;

    fheader_ptr = fopen("data/pebble.hdr","rb");

    if(fheader_ptr == NULL) 
       {
            printf("Error! opening pebble.hdr file");
            exit(1);
       }

    fmovie_ptr = fopen("data/pebble.mvlp","rb");

    if(fmovie_ptr == NULL) 
       {
            printf("Error! opening pebble.mvlp file");
            exit(1);
       }

    fmovie_filename_ptr = fopen("data/pebble.filenames","rb");

    if(fmovie_filename_ptr == NULL) 
       {
            printf("Error! opening pebble.filenames file");
            exit(1);

/* 

    Read header file for movie cube
    We need movie frame size --  Nx by Nz

    We need the number of frames...  -- Nframes
*/
          fread(&nframe,sizeof(int),1, fheader_ptr);
          fread(&nx,sizeof(int),1, fheader_ptr);
          fread(&nz,sizeof(int),1, fheader_ptr);
          fread(&nfchar,sizeof(int),1, fheader_ptr);

          printf("  Movie loop has %d frames \n"  ,nframe);
          printf("  Movie frame has %d rows \n"   ,nz);
          printf("  Movie loop has %d columns \n" ,nx);
          printf("  Movie file name has %d characters \n" ,nfchar);
          printf("  Frame length is %d floats \n" ,frame_length);
    
          fclose(fheader_ptr);

/*   
    Now read all the movie frames  

*/
    frame_length = 256*256;

         for(int ifr=0;ifr<nframe;ifr++) 
         {

//   Now read actual movie file name 
          fgets(filename,25, fmovie_filename_ptr);

//   Now read actual movie loop frame
          fread(&wave,sizeof(float),frame_length, fmovie_ptr);

//   Find max floating point in array wave().
            float wave_maxp = 0.0;
            float wave_maxn = 0.0;
            for(int ixz=0;ixz<frame_length;ixz++) 
            {
              if( wave[ixz] >= wave_maxp ) wave_maxp = wave[ixz];
              if( wave[ixz] <= wave_maxn ) wave_maxn = wave[ixz];
            }

            printf(&filename);
            printf("  Frame  %d  " ,ifr);
            printf("  Wave Max Positive=  %f  " ,wave_maxp);
            printf("  Max Negative=  %f  \n" ,wave_maxn);
            
         }


          fclose(fmovie_ptr);

          return 0;

} /* end of main program */
