/*    c program to map 
      floating point range 
      into argb integer

      test code to prepare for doing tpebble.c

      Phil Bording
      July 16, 2020
      Blue Waters Project

*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>


int main()
{

//    data maximum positive number
//    data maximum negative number

    float dmaxp;
    float dmaxm;

    float pmax;

    float smax;
    float smin;


//    end result argb integer

    int   irgb;

    dmaxp =  2.6;
    dmaxm = -2.2;

    pmax  = fmaxf(dmaxp,abs(dmaxm));

    smax = 2.0*pmax;
    smin = 0.0;
/*
                         hex
                         a r g b
          grey scale  =  ff000000 = black
          grey scale  =  ffffffff = white

          binary         44444444   bits = 32 bits

*/

    float sgrey = 0.0;
    float dgrey = 1.0;

    float smov = -0.5*smax;
    float dmov =  smax/256.0;

     int ibit;
     int mone;
     int mrgb;

     mone = -256*256*256;
     for(int  i=1;i<=255;i=i+1) 
      {
         irgb = 256*256*i + 256*i + i;
         mrgb = mone + irgb;
         printf("  %-9.3f   %-9f  %-10d %-9x  \n",sgrey,smov,mrgb,mrgb);
         sgrey = sgrey + dgrey;
         smov  = smov +dmov;
      }

    return 0;

} /* end of main program */
