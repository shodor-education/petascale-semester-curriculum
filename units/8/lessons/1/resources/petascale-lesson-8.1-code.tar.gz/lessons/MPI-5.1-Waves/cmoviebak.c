/*    c program to read the pebble movie loop 
      floating point file

      test code to prepare for doing tpebble.c

      Phil Bording
      July 15, 2020
      Blue Waters Project

*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>


int main()
{

    int nx;
    int nz;

    int nframe;


    FILE  *fmovie_ptr;
    FILE  *fheader_ptr;

    if((fheader_ptr = fopen("pebble.hdr","rb")) == NULL) {
            printf("Error! opening pebble.hdr file");
            exit(1);
       }

    if((fmovie_ptr = fopen("pebble.mvlp","rb")) == NULL) {
            printf("Error! opening pebble.movie file");
            exit(1);
       }
/* 

    Read header file for movie cube
    We need movie frame size --  Nx by Nz

    We need the number of frames...  -- Nframes
*/
          fread(&nframe,sizeof(int),1, fheader_ptr);
          fread(&nx,sizeof(int),1, fheader_ptr);
          fread(&nz,sizeof(int),1, fheader_ptr);

          fprintf("  Movie loop has %d frames "  ,nframe);
          fprintf("  Movie frame has %d rows "   ,nz);
          fprintf("  Movie loop has %d columns " ,nx);

    
          fclose(fheader_ptr);
          fclose(fmovie_ptr);

          return 0;

} /* end of main program */
