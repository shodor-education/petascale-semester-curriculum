/*    c program to read the pebble movie loop 
      floating point file

      test code to prepare for doing tpebble.c

      Phil Bording
      July 15, 2020
      Blue Waters Project

*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>


int main()
{

    int nx;
    int nz;

    int nframe;
    int nfchar;


    FILE *fptr;

    fptr = fopen("data/pebble.hdr","rb");

    if(fptr == NULL) 
       {
            printf("Error! opening data/pebble.hdr file");
            exit(1);
       }

    nx = 0;
    nz = 0;
    nframe = 0;
/* 

    Read header file for movie cube
    We need movie frame size --  Nx by Nz

    We need the number of frames...  -- Nframes
*/
          fread(&nframe,sizeof(int),1, fptr);
          fread(&nx,sizeof(int),1, fptr);
          fread(&nz,sizeof(int),1, fptr);
          fread(&nfchar,sizeof(int),1, fptr);

           printf("  Movie loop has %d frames \n"  ,nframe);
           printf("  Movie frame has %d rows \n"   ,nz);
           printf("  Movie loop has %d columns \n" ,nx);
           printf("  Movie filename has %d characters \n" ,nfchar);

    
          fclose(fptr);

          return 0;

} /* end of main program */
